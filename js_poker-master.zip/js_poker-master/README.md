js_poker
========

A simple, minimalist scaffold for a poker web app frontend
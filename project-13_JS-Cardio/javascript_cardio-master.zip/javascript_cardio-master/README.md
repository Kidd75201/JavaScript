# JavaScript Cardio

> Intermediate JavaScript challenges.

Feel free to make a pull request but please use the "index_extra.js" file. Comment out your solution and leave "Solution By [YOUR NAME]". Please keep the file neat and do NOT change anyone elses solutions
